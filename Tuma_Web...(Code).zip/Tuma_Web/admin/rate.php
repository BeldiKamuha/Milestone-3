<?php
	session_start();
	require_once "../config/dbConnect.php";
	include "../templates/adminTemplates.php";
	
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Tuma</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	
</head>
<body>

		<section class="home-section">
		<!--Home-content-->
		<div class="home-content">
		
		<div class="bootstrap-two">
		<div class="container">
      
		<h4 style="text-align: center;"><u>View Traders' ratings</u></h4>
		<br/>
      <table style="color:white;" class="table table-hover">
	<thead>
		<tr>
		<th scope="col">No</th>
		<th scope="col">Trader's name </th>
		<th scope="col">Rate </th>
		
	
      
    </tr>
  </thead>
  <tbody>
  
	
    <?php 
	$cn=0;
	$res_tbl_rate = $dbConn->query("SELECT * FROM `tbl_rate` ");
	while($row_tbl_rate = $res_tbl_rate->fetch_assoc()){ $cn++;
		   ?>
    <tr>
      <th scope="row"><?php print $cn; ?></th>
      
      <td><?php print $row_tbl_rate["trader_name"];?></td>
      <td><?php print $row_tbl_rate["rate"];?> %</td> 
	   
	  
     
	  </tr>
	  <?php } ?>
    
   
  </tbody>
</table>
    
      </div>
	  </div>
      </div>
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
