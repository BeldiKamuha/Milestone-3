<?php
	session_start();
	require_once "../config/dbConnect.php";
	include "../templates/adminTemplates.php";
	
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Tuma</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
</head>
<body>

		<section class="home-section">
		<!--Home-content-->
		<div class="home-content">
		
		<div class="bootstrap">
		<div class="container">
      

      <div class="row">
        
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3" style="text-align: center;">Register trader</h4>
		   <br/> <br/> 
		  
          <form class="needs-validation" method="post" action="../processes/registerTrader_processes.php" enctype ="multipart/form-data" >
		  <h4 style="text-align: center;"><u>Register trader</u></h4>
		    <br/>
          <div class="row">
		  
		  <div class="col-md-6 mb-3">
                <label for="surname">Surname:<span style = "color: #dd0000;">*</span></label>
                <input type="text" class="form-control" id="surname" name="surname" placeholder="Enter surname " value="" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
              <div class="col-md-6 mb-3">
                <label for="firstname">First name:<span style = "color: #dd0000;">*</span></label>
                <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter firstname" value="" required />
                <div class="invalid-feedback">
                
                </div>
              </div>
              
			  <div class="col-md-6 mb-3">
                <label for="othername">Other name:</label>
                <input type="text" class="form-control" id="othername" name="othername" placeholder="Enter othername" value=""  />
                <div class="invalid-feedback">
                
                </div>
              </div>
			  
			  <div class="col-md-6 mb-3">
				<label for="profile_pic">Profile Picture:<span style = "color: #dd0000;">*</span></label>
                <input type="file" class="form-control" id="profile_pic" name="profile_pic" placeholder="" value="" required>
                <div class="invalid-feedback">
              </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="gender">Gender:<span style = "color: #dd0000;">*</span></label>
				<select class="form-control" id="gender" name = "gender" required>
			<option for="gender" value = "">--Select gender--</option>
			<option value = "Male">M</option>
			<option value = "Female">F</option>
			</select>
			 <div class="invalid-feedback">
                  
                  
                </div>
              </div>
			  
              <div class="col-md-6 mb-3">
                <label for="dob">Date of birth:<span style = "color: #dd0000;">*</span></label>
                <input type="date" class="form-control" id="dob" name="dob" placeholder="" value="" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
			  </div>
			 
                <div class="mb-3">
              <label for="email">Email address:<span style = "color: #dd0000;">*</span></label>
              <input type="email" class="form-control" id="email" name="email"placeholder="Enter email" required />
              <div class="invalid-feedback">
            
              </div>
            </div> 
          

			<div class="row">
              <div class="col-md-6 mb-3">
                <label for="password">Password:<span style = "color: #dd0000;">*</span></label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" value="" required />
                <div class="invalid-feedback">
                
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="confirmpassword">Confirm password:<span style = "color: #dd0000;">*</span></label>
                <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm password " value="" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
              </div> 
			  
			
			<div class="mb-3">
             <label for="role">Role:<span style = "color: #dd0000;">*</span></label>
              <select class="form-control" id="transport_type" name = "role" >
			  <option for="role" value = "">--Select Role--</option>
			  <?php 
	$cn=0;
	$res_tbl_roles = $dbConn->query("SELECT * FROM `tbl_roles` where role_id != 1 && role_id != 3  ");
	while($row_tbl_roles = $res_tbl_roles->fetch_assoc()){ $cn++;?>
				<option value = "<?php print $row_tbl_roles["role_id"];?>"><?php print $row_tbl_roles["role_name"];?></option>
				  <?php } ?>
				
				</select>
              <div class="invalid-feedback">
                  
                </div>
              </div>
           
           <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit" name = "registerTrader">Register</button>
			
			
			
          </form>
        </div>
      </div>
      </div>
	  </div>
      </div>
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
