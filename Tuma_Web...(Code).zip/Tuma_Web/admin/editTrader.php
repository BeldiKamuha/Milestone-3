 <?php
	session_start();
	require_once "../config/dbConnect.php";
	include "../templates/adminTemplates.php";
	?>
<?php
	if(isset($_GET["EditTrader"])){
	$EditTrader = mysqli_real_escape_string($dbConn, $_GET["EditTrader"]);
	
	$res_tbl_users = $dbConn->query("SELECT * FROM `tbl_users`   WHERE user_id = '$EditTrader' LIMIT 1"); 
	$row_tbl_users = $res_tbl_users->fetch_assoc();
	
	}
 ?>

<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Cafe</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
</head>
<body>

		<section class="home-section">
		<!--Home-content-->
		<div class="home-content">
		
		<div class="bootstrap">
		<div class="container">
      

      <div class="row">
        
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3" style="text-align: center;">Edit server</h4>
		   <br/> <br/> 
		  
          <form class="needs-validation" method="post" action="../processes/registerTrader_processes.php" enctype ="multipart/form-data" >
		  <h4 style="text-align: center;"><u>Edit server</u></h4>
		    <br/>
          <div class="row">
		  
		  <div class="col-md-6 mb-3">
                <label for="surname">Surname:<span style = "color: #dd0000;">*</span></label>
                <input type="text" class="form-control" id="surname" name="surname" placeholder="Enter surname " value="<?php print $row_tbl_users["surname"];?>" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
              <div class="col-md-6 mb-3">
                <label for="firstname">First name:<span style = "color: #dd0000;">*</span></label>
                <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter firstname" value="<?php print $row_tbl_users["firstname"];?>" required />
                <div class="invalid-feedback">
                
                </div>
              </div>
              
			  <div class="col-md-6 mb-3">
                <label for="othername">Other name:</label>
                <input type="text" class="form-control" id="othername" name="othername" placeholder="Enter othername" value="<?php print $row_tbl_users["othername"];?>"  />
                <div class="invalid-feedback">
                
                </div>
              </div>
			  
			  <div class="col-md-6 mb-3">
				<label for="profile_pic">Profile Picture:<span style = "color: #dd0000;">*</span></label>
                <input type="file" class="form-control" id="profile_pic" name="profile_pic" placeholder="" value="<?php print $row_tbl_users["profile_pic"];?>" required>
                <div class="invalid-feedback">
              </div>
              </div>
              <div class="col-md-6 mb-3">
				<label for="gender">Update Gender:</label>
				<select class="form-control" id="gender" name = "gender" >
			<option for="gender" value = "<?php print $row_tbl_users["gender"];?>"><?php print $row_tbl_users["gender"];?></option>
			<option for="gender" value = "">--Select gender--</option>
			<option value = "Male">M</option>
			<option value = "Female">F</option>
			</select>
			 <div class="invalid-feedback">
                  
                </div>
              </div>
			  
              <div class="col-md-6 mb-3">
                <label for="dob">Date of birth:<span style = "color: #dd0000;">*</span></label>
                <input type="date" class="form-control" id="dob" name="dob" placeholder="" value="<?php print $row_tbl_users["dob"];?>" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
			  </div>
			 
                <div class="mb-3">
              <label for="email">Email address:<span style = "color: #dd0000;">*</span></label>
              <input type="email" class="form-control" id="email" name="email"placeholder="Enter email" value="<?php print $row_tbl_users["email"];?>" required />
              <div class="invalid-feedback">
            
              </div>
            </div> 
          

                <div class="invalid-feedback">
                 
             <input type="hidden"  name = "user_id" value="<?php print $row_tbl_users["user_id"]; ?>" />
              
                </div>
              
			  
			
			
           
           <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit" name = "editTrader">Edit <?php print $row_tbl_users["surname"];?></span><?php print "&nbsp";?><span><?php  print $row_tbl_users ["firstname"];?></span></button>
			
			
			
          </form>
        </div>
      </div>
      </div>
	  </div>
      </div>
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
