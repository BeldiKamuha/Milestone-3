<?php
	session_start();
	require_once "../config/dbConnect.php";
	
	
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Tuma</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
</head>
<body>

	<section id="menu">
	
		<div class="logo">
			<!--<img src="../images/logo.jpg" alt="">-->
			<h1>Tuma<h1>
		</div>
		
		<div class="items">
		<li><i class='bx bxs-dashboard' ></i><a href="trader.php">Dashboard</a></li>
		<li><i class='bx bx-edit-alt' ></i><a href="uploadProduct.php">Upload product</a></li>
		<li><i class='bx bxs-food-menu'></i><a href="productSold.php">Product sold</a></li>
		<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
		
		
		
		
		<li><i class='bx bx-line-chart'></i><a href="../processes/user_processes.php?logout">Log out</a></li>
		
		</div>

	</section>
	
	<section id="interface">
		<div class="navigation">
			<div class="n1">
				<div>
					<i id="menu-btn"class='bx bx-menu sidebarBtn'></i>
				</div>
				<div class="search">
					<i class='bx bx-search-alt-2' ></i>
					<input type="text" placeholder="search">
		
				</div>
			</div>
			<div class="profile">
				<i class='bx bx-bell'></i>
				<!--<img src="../images/profile.jpg">-->
			</div>
		</div>
		<h3 class="i-name">
		Trader | Dashboard
		</h3>
		
		<div class="values">
			<div class="val-box">
				<a href="uploadedProduct.php"><i class='bx bxs-user-detail'></i></a>
				<div>
					<a style="text-decoration:none;" href="uploadedProduct.php"><h4>View Uploaded products</h4></a>
					<span>Manage products</span>
				
				</div>
			</div>
			<div class="val-box">
				<a href="productSold.php"><i class='bx bxs-food-menu'></i></a>
				<div>
					<a style="text-decoration:none;" href="productSold.php"><h4>View product sold</h4></a>
					<span>For clients</span>
				
				</div>
			</div>
			<div class="">
			
			</div>
			
			
			
		</div>
		
		
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
