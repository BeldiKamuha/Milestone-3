<?php
	session_start();
	require_once "../config/dbConnect.php";
	include "../templates/traderTemplates.php";
	
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Tuma</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
	
</head>
<body>

		<section class="home-section">
		<!--Home-content-->
		<div class="home-content">
		
		<div class="bootstrap-two">
		<div class="container">
      
		<h4 style="text-align: center;"><u>Uploaded products</u></h4>
		<br/>
      <table style="color:white;" class="table table-hover">
	<thead>
		<tr>
		<th scope="col">No</th>
		<th scope="col">Name </th>
		<th scope="col">Selling price</th>
		<th scope="col">Actions</th>
		
	
      
    </tr>
  </thead>
  <tbody>
  
	
    <?php 
	$cn=0;
	$res_tbl_product = $dbConn->query("SELECT * FROM `tbl_product` ");
	while($row_tbl_product = $res_tbl_product->fetch_assoc()){ $cn++;
		   ?>
    <tr>
      <th scope="row"><?php print $cn; ?></th>
      <td><img width="50px" height="50px" src="../images/product/<?php print $row_tbl_product["product_image"];?>"/> <?php print $row_tbl_product["product_name"];?></td>
      <td>Ksh <?php print $row_tbl_product["product_sellingprice"];?></td> 
	 
	  
      
	  <td>
	  [<a href="editProduct.php?EditProduct=<?php print $row_tbl_product["product_id"];?>">Edit</a> ] 
	  [<a href="../processes/uploadProduct_processes.php?DeleteProduct=<?php print $row_tbl_product["product_id"];?>">Delete</a> ]
	  </td>
	  </tr>
	  <?php } ?>
    
   
  </tbody>
</table>
      </div>
	  </div>
      </div>
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
