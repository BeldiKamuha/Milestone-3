	<section id="menu">
	
		<div class="logo">
			<!--<img src="../images/logo.jpg" alt="">-->
			<h2>Tuma<h2>
		</div>
		
		<div class="items">
		<li><i class='bx bxs-dashboard' ></i><a href="trader.php">Dashboard</a></li>
		<li><i class='bx bx-edit-alt' ></i><a href="uploadProduct.php">Upload product</a></li>
		<li><i class='bx bxs-food-menu'></i><a href="productSold.php">Product sold</a></li>

		<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
		
		
		
		
		<li><i class='bx bx-line-chart'></i><a href="../processes/user_processes.php?logout">Log out</a></li>
		
		</div>

	</section>
	
	<section id="interface">
		<div class="navigation">
			<div class="n1">
				<div>
					<i id="menu-btn"class='bx bx-menu sidebarBtn'></i>
				</div>
				<div class="search">
					<i class='bx bx-search-alt-2' ></i>
					<input type="text" placeholder="search">
		
				</div>
			</div>
			<div class="profile">
				<i class='bx bx-bell'></i>
				<!--<img src="../images/profile.jpg">-->
			</div>
		</div>