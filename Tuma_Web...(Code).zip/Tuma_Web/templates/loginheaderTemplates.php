

	<!--Header-->
		<div class="header" id="home">
		<!--top-bar-->
		<div class="top-bar_w3agileits">
			<div class="top-logo_info_w3layouts">
				<div class="col-md-3 logo">
					<h1><a class="navbar-brand" href="index.php">Tuma<span></span></a></h1>
				</div>
				<div class="col-md-9 adrress_top">
					<div class="adrees_info">
						<!-- <div class="col-md-6 visit">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-home" aria-hidden="true"></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
								<h4>Visit us</h4>
								<p>Olesangale road,BO, Nairobi</p>
							</div>
							<div class="clearfix"></div>
						</div> -->
						<div class="col-md-6 mail-us">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-envelope" aria-hidden="true"></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
								<h4>Mail us</h4>
								<p><a href="mailto:info@example.com">info@Tuma.com</a></p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="col-md-6 visit">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-user" aria-hidden="true"><i class='bx bx-home-alt-2'></i></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
							 
								<h4><a href="signup.php"> Sign up </a></h4>
									
								<p></p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<ul class="top-right-info_w3ls">
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					</ul>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			
		</div>
	</div>

	