<?php
	session_start();
	require_once "../config/dbConnect.php";
	include "../templates/clientTemplates.php";
	
?>

<?php
	if(isset($_GET["EditProduct"])){
	$EditProduct = mysqli_real_escape_string($dbConn, $_GET["EditProduct"]);
	
	$res_tbl_product = $dbConn->query("SELECT * FROM `tbl_product`   WHERE product_id = '$EditProduct' LIMIT 1"); 
	$row_tbl_product = $res_tbl_product->fetch_assoc();
	
	}
 ?>
 
<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8"/>
	<title>Cafe</title>
	<meta name= "viewport" content =
	"width=device-width, initial-scale=1.0" /> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="../css/dashboardLayoutStructure.css" />
	<!--BoxIcons CDN Link-->
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet' >
	<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/checkout/">

    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="form-validation.css" rel="stylesheet">
	
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	
</head>
<body>

		<section class="home-section">
		<!--Home-content-->
		<div class="home-content">
		
		<div class="bootstrap">
		<div class="container">
      

      <div class="row">
        
        <div class="col-md-8 order-md-1">
          <h4 class="mb-3" style="text-align: center;">Buy products</h4>
		   <br/> <br/> 
		  
          <form class="needs-validation" method="post" action="../processes/buyProduct_processes.php" enctype ="multipart/form-data" >
		  <h4 style="text-align: center;"><u>Buy products</u></h4>
		    <br/>
          <div class="row">
		 
			  <div class="col-md-6 mb-3">
                <label for="product_name">Product name</label>
                <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter food name " value="<?php print $row_tbl_product["product_name"];?>" required />
				
                <div class="invalid-feedback">
                  
                </div>
              </div> 
           
			  <div class="col-md-6 mb-3">
                <label for="product_sellingprice">Product selling price</label>
                <input type="number" class="form-control" id="product_sellingprice" name="product_sellingprice" placeholder="selling price on" value="<?php print $row_tbl_product["product_sellingprice"];?>" required />
                <div class="invalid-feedback">
                  
                </div>
              </div> 
			  </div>
          

			
               <div class="invalid-feedback">
                 
             <input type="hidden"  name = "product_id" value="<?php print $row_tbl_product["product_id"]; ?>" />
              
                </div>
               
			  
			
           
           <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit" name = "buyProduct">Buy</button>
			
			
			
          </form>
        </div>
      </div>
      </div>
	  </div>
      </div>
	
	</section>
	
	<script>
	$('#menu-btn').click(function(){
		$('#menu').toggleClass("active");
		
	})
	
	</script>
	
	

</body>
</html>

    
