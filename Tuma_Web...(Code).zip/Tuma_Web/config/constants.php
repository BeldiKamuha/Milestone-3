<?php

	define("HOSTNAME","localhost");
	define("HOSTUSER","root");
	define("HOSTPASS","");
	define("DBNAME","tuma");



?>