<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Megacorp a Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
    

    <title>AGRIMGT FARM | index</title>
    <script type="application/x-javascript">
        addEventListener("load", function (){
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar(){
            window.scrollTo(0, 1);
        }
    
    </script>
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
	<link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css' />
	<link href="css/home.css" rel='stylesheet' type='text/css' />
	<link href="css/mail.css" rel="stylesheet" type='text/css' media="all" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto+Mono:300,300i,400,400i,500,500i,700" rel="stylesheet">
</head>

<body>
	<!--Header-->
	<div class="header" id="home">
		<!--top-bar-w3-agile-->
		<div class="top-bar_w3agileits">
			<div class="top-logo_info_w3layouts">
				<div class="col-md-3 logo">
					<h1><a class="navbar-brand" href="index.php">Tuma<span> </span></a></h1>
				</div>
				<div class="col-md-9 adrress_top">
					<div class="adrees_info">
						
						<div class="col-md-6 mail-us">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-envelope" aria-hidden="true"></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
								<h4>Mail us</h4>
								<p><a href="mailto:info@example.com">info@Tuma.com</a></p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="col-md-6 visit">
							<div class="col-md-2 col-sm-2 col-xs-2 contact-icon">
								<span class="fa fa-user" aria-hidden="true"></span>
							</div>
							<div class="col-md-10 col-sm-10 col-xs-10 contact-text">
								<h4><a href = "login.php"> <h4> Login </h4>  </a></h4>
								<p>My account!</p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<ul class="top-right-info_w3ls">
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					</ul>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-nav">
				<div class="inner-nav_wthree_agileits">
					<nav class="navbar navbar-default">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
							<nav>
								<ul class="nav navbar-nav">
									<li><a href="index.php" class="active">Home</a></li>
									<li><a href="#">About</a></li>
									<li><a href="signup.php">Register</a></li>
								</ul>
							</nav>

						</div>
					</nav>
					<div class="search">
						<div class="cd-main-header">
							<ul class="cd-header-buttons">
								<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
							</ul>
							<!-- cd-header-buttons -->
						</div>
						<div id="cd-search" class="cd-search">
							<form action="#" method="post">
								<input name="Search" type="search" placeholder="Click enter after typing...">
							</form>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!--//top-bar-w3-agile-->
		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="banner-top">
							<div class="banner-info_agileits_w3ls">
								<h3>Tuma</h3>
								<p>- For Clients satisfaction</p>
								<a href="#">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
								<a href="#">Contact Us <i class="fa fa-caret-right" aria-hidden="true"></i></a>
							</div>

						</div>
					</li>
					<li>
    
                    <!--  SLIDING MENU PHOTOS ON THE HOME INDEX.HTML  3 MENUS-SLIDE-->

                    <div class="banner-top1">
                        <div class="banner-info_agileits_w3ls">
                            <h3>Tuma</h3>
                            <p>- For Clients satisfaction</p>
                            <a href="#">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                            <a href="#">Contact Us <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>

                    </div>
                </li>
                <li>
                    <div class="banner-top2">
                        <div class="banner-info_agileits_w3ls">
                            <h3>Tuma</h3>
                            <p>- For Clients satisfaction</p>
                            <a href="@">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                            <a href="#">Contact Us <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>

                    </div>
                </li>
                <li>
                    <div class="banner-top3">
                        <div class="banner-info_agileits_w3ls">
                            <h3>Tuma</h3>
                            <p>- For Clients satisfaction</p>
                            <a href="#">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                            <a href="#">Contact Us <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>

                    </div>
                </li>
				
            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
    <!-- PHOTO SLIDES IN HOME PAGE -->
    <!-- /about -->

    

	


	<!-- copyright -->
	<div class="copyright">
		<div class="container">
			<div class="copyrighttop">
				<ul>
					<li>
						<h4>Follow us on:</h4>
					</li>
					<li><a class="facebook" href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a class="facebook" href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a class="facebook" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					<li><a class="facebook" href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
				</ul>
			</div>
			<div class="copyrightbottom">
				<p><b>Copyright &copy; <?php echo date("Y"); ?> | TUMA ONLINE TRADING SYSTEM - All rights reserved</b></p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

    <!-- HELLO JAVA-SCRIPT !! -->

    <script type="text/javascript" src="javaScript/jquery-2.2.3.min.js"></script>
    <!-- //js -->
	<!--search-bar-->
	<script src="javaScript/main.js"></script>
    <!--//search-bar-->
	<script>
		$('ul.dropdown-menu li').hover(function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
		}, function () {
			$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
		});
	</script>

    <!-- stats -->
	<script src="javaScript/jquery.waypoints.min.js"></script>
	<script src="javaScript/jquery.countup.js"></script>
	<script>
		$('.counter').countUp();
	</script>
	<!-- //stats -->


	<script src="javaScript/responsiveslides.min.js"></script>
	<script>
		$(function () {
			$("#slider4").responsiveSlides({
				auto: true,
				pager: true,
				nav: true,
				speed: 1000,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});
		});
	</script>
    <!-- script for responsive tabs -->
	<script src="javaScript/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true, // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
			$('#verticalTab').easyResponsiveTabs({
				type: 'vertical',
				width: 'auto',
				fit: true
			});
		});
	</script>

    <!--// script for responsive tabs -->
	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="javaScript/move-top.js"></script>
	<script type="text/javascript" src="javaScript/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 900);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->

	<script type="text/javascript">
		$(document).ready(function () {
			/*
									var defaults = {
							  			containerID: 'toTop', // fading element id
										containerHoverID: 'toTopHover', // fading element hover id
										scrollSpeed: 1200,
										easingType: 'linear' 
							 		};
									*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<script type="text/javascript" src="javaScript/bootstrap-3.1.1.min.js"></script>


   
    
</body>
</html>